#include "mi_disp.h"
#include "sysdisplay.h"
//#include "SAT070CP50_1024x600.h"
#include "mi_panel.h"

#define MAKE_YUYV_VALUE(y,u,v) ((y) << 24) | ((u) << 16) | ((y) << 8) | (v)
#define YUYV_BLACK MAKE_YUYV_VALUE(0,128,128)

int disp_init();

