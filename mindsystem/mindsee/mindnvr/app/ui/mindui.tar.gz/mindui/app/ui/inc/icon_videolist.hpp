#ifndef __ICON_VIDEOLIST_HPP__
#define __ICON_VIDEOLIST_HPP__

#include "minigui_entry.hpp"
#include "minigui_resource.hpp"

extern int UI_OnIconVideoList(int val);

#endif
