#ifndef __ICON_NVROPTIONS_HPP__
#define __ICON_NVROPTIONS_HPP__

#include "minigui_entry.hpp"
#include "minigui_resource.hpp"

extern int UI_OnIconNvrOptions(int val);

#endif

