#ifndef __ICON_SETTIME_HPP__
#define __ICON_SETTIME_HPP__

#include "minigui_entry.hpp"
#include "minigui_resource.hpp"

extern int UI_OnIconSetTime(int val);

#endif

