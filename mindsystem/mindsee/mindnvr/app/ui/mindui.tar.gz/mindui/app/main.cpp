#include <thread>
#include "disp_init.hpp"
#include "minigui_entry.hpp"

using namespace std;

static bool s_running;

int main(int argc, const char *arg[])
{
    disp_init();

	UI_print("ready to call UI_ModuleLoad().\n");
	if(UI_ModuleLoad() != 0)
	{
		UI_perror("In manager::run()", "Fail to load UI module!\n");
    }
	else
	{
		UI_print("Success to load UI module!\n");
	}

	UI_print("ready to call UI_Run().\n");
	UI_ModuleRun();

	s_running = true;
	while(s_running)
	{
	    this_thread::sleep_for(chrono::seconds(1));
	}

	UI_print("Ready to call UI_ModuleUnload.\n");
	UI_ModuleUnload();
	UI_print("End of Call UI_ModuleUnload.\n");

	printf("#####exit\n");

	return 0;
}
