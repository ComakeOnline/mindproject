#ifndef __MINIGUI_BOOTSCREEN_H__
#define __MINIGUI_BOOTSCREEN_H__

#include "minigui_entry.hpp"
#include "minigui_resource.hpp"

int UI_BootScreen();

#endif

