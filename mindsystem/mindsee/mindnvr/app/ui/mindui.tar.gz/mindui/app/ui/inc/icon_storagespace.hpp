#ifndef __ICON_STORAGESPACE_HPP__
#define __ICON_STORAGESPACE_HPP__

#include "minigui_entry.hpp"
#include "minigui_resource.hpp"

extern int UI_OnIconStorageSpace(int val);

#endif
