#ifndef __ICON_SYSINFO_HPP__
#define __ICON_SYSINFO_HPP__

#include "minigui_entry.hpp"
#include "minigui_resource.hpp"

extern int UI_OnIconSysInfo(int val);

#endif
