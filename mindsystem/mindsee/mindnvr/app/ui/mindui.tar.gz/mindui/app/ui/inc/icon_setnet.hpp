#ifndef __ICON_SETNET_HPP__
#define __ICON_SETNET_HPP__

#include "minigui_entry.hpp"
#include "minigui_resource.hpp"

extern int UI_OnIconSetNet(int val);

#endif

