该文件由创建于lison.guo，用于存放UI所需的资源文件。

该文件夹应该放在开发板的/customer 下。
