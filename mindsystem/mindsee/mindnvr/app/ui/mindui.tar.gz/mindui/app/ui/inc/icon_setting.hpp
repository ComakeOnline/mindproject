#ifndef __ICON_SETTING_HPP__
#define __ICON_SETTING_HPP__

#include "minigui_entry.hpp"
#include "minigui_resource.hpp"

extern int UI_OnIconSetting(int val);

#endif

